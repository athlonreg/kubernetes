package com.load.extend;

/**
 * ExtendDataHandle此接口不允许任何修改
 * 数据处理扩展接口，所有的数据处理类必须实现这个接口,
 * 必须实现dataHandle函数（因为只能通过调用dataHandle函数实现数据的处理）
 */
public interface ExtendDataHandle {

    /**
     *
     * @param value
     * @return
     */
    String dataHandle(String value);
}
