package com.load.extend;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * 这是数据处理函数样例，实现了ExtendDataHandle接口,实现了dataHandle接口,
 * 通过调用dataHandle接口处理数据
 */
public class MyDataHandle implements ExtendDataHandle {
    public String dataHandle(String value) {
        JSONObject jsonObject = JSON.parseObject(value);
        jsonObject.put("field", "fieldDemo");
        return jsonObject.toString();
    }
}
